import DDK
import time


def int_to_bytes(inp):
    pos = inp.to_bytes(2, 'big', signed =True)
    pos2 = [int(pos[0]), int(pos[1])]
    return pos2

def bytes_to_int(byte_list):
    # Combine the list of bytes into a bytes object
    byte_data = bytes(byte_list)
    # Convert the bytes object back to a signed integer
    return int.from_bytes(byte_data, 'big', signed=True)

Gpio = DDK.DDKGPIO()
if( Gpio.Open()):
    print("Could not open DDK GPIO")
    quit()

Gpio.Write(Gpio.GPIO_POWER_ON,True)

I2C = DDK.DDKI2C()
I2C.Open()

device = 0x29

time.sleep(1)

print("Waking up drive")
I2C.Write(device, 0x1C, []) # Wake up

time.sleep(3)

print("Go to position")
I2C.Write(device, 0x05, int_to_bytes(3000)) # Go to position 300
time.sleep(1)
print("Go to another position")
I2C.Write(device, 0x05, int_to_bytes(0)) # Go to position 0
time.sleep(2)
print("Done.. Closing DDK")

I2C.Close()
Gpio.Close()
