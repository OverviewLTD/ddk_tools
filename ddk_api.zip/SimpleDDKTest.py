import time
import DDK

device = 0x29
I2C = DDK.DDKI2C()
I2C.Open()

time.sleep(0.5)
Data = I2C.ReadSlow(device, 0x1B, 4)
print("FW = " + str(Data))

print("Waking up drive")
I2C.Write(device, 0x1C, []) # Wake up

time.sleep(3)

I2C.Write(device, 0x07, [0x00, 0x01])

Data = I2C.ReadSlow(device, 0x1B, 4)
print(Data)

