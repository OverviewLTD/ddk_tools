import DDK

I2C = DDK.DDKI2C()
I2C.Open()

Drives = I2C.FindDrives(start=0x01, end=0x7F)

print("Found: ", end="")
for i in Drives:
    print(hex(i) + ", ", end="")
print("")
I2C.Close()
