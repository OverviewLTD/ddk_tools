#ifndef DDK_H
#define DDK_H

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
// #include "ftd2xx.h"

/* Define ADD_EXPORTS when building the DLL. */
#define ADD_EXPORTS
#ifdef ADD_EXPORTS
#define ADDAPI __declspec(dllexport)
#else
#define ADDAPI __declspec(dllimport)
#endif

/* Define calling convention in one place, for convenience. */
#define ADDCALL __cdecl

/* Make sure functions are exported with C linkage under C++ compilers. */

#ifdef __cplusplus
extern "C"
{
#endif
    struct DDKI2CTypeStruct;
    typedef struct DDKI2CTypeStruct *DDKI2CType;

    struct DDKCANTypeStruct;
    typedef struct DDKCANTypeStruct *DDKCANType;

    struct DDKGPIOTypeStruct;
    typedef struct DDKGPIOTypeStruct *DDKGPIOType;

    struct DDKUARTTypeStruct;
    typedef struct DDKUARTTypeStruct *DDKUARTType;

    typedef struct
    {
        DDKI2CType I2C;
        DDKCANType CAN;
        DDKGPIOType GPIO;
        DDKUARTType UART;
    } DDKType;

    /*******************/
    /*** I2C      *****/
    /*******************/

    typedef enum
    {
        DDK_OK,
        DDK_NOT_FOUND, // could disconnection , device initialisation
        DDK_NACK,
        DDK_INVALID_PARAMETER,
        DDK_BUS_ERROR

    } DDK_STATUS;

    ADDAPI DDKI2CType ADDCALL DDKI2COpen(void);
    ADDAPI DDKI2CType ADDCALL DDKI2COpenEx(uint32_t LocationID);
    ADDAPI DDK_STATUS ADDCALL DDKI2CClose(DDKI2CType DDK);
    ADDAPI DDK_STATUS ADDCALL DDKI2CRead(DDKI2CType DDK, unsigned char slaveAddress, unsigned char registerAddress, unsigned char *data, unsigned int numBytes);
    ADDAPI DDK_STATUS ADDCALL DDKI2CReadSlow(DDKI2CType DDK, unsigned char slaveAddress, unsigned char registerAddress, unsigned char *data, unsigned int numBytes);
    ADDAPI DDK_STATUS ADDCALL DDKI2CReadStretch(DDKI2CType DDK, unsigned char slaveAddress, unsigned char registerAddress, unsigned char *data, unsigned int numBytes);
    ADDAPI DDK_STATUS ADDCALL DDKI2CWrite(DDKI2CType DDK, unsigned char slaveAddress, unsigned char registerAddress, const unsigned char *data, unsigned int numBytes);
    ADDAPI DDK_STATUS ADDCALL DDKI2CWriteFast(DDKI2CType DDK, unsigned char slaveAddress, unsigned char registerAddress, const unsigned char *data, unsigned int numBytes);
    ADDAPI DDK_STATUS ADDCALL DDKI2CWriteEx(DDKI2CType DDK, unsigned char slaveAddress, unsigned char registerAddress, const unsigned char *data, unsigned int numBytes, bool FastMode);
    ADDAPI DDK_STATUS DDKI2CScanDeviceID(DDKI2CType DDK, uint32_t ID);
    ADDAPI void ADDCALL DDKI2CSetLatency(DDKI2CType DDK, uint32_t Latency);

    /* General */
    ADDAPI uint32_t ADDCALL DDKNumConnectedDDKs(void);
    ADDAPI int32_t ADDCALL DDKScanDevices(uint32_t *DeviceIDs, uint32_t Len);

    /*******************/
    /*** GPIO      *****/
    /*******************/
    typedef enum
    {
        GPIO_POWER_ON = 0,
        GPIO_UART_SELECT = 1,
        GPIO_DRIVE_KILL = 2,
        GPIO_PAN_TILT = 3,
        GPIO_CAN_INT = 4,
        GPIO_NUM_PINS
    } GPIO_PIN;

    ADDAPI DDKGPIOType ADDCALL DDKGPIOOpen(void);
    ADDAPI DDKGPIOType ADDCALL DDKGPIOOpenEx(uint32_t LocationID);
    ADDAPI void ADDCALL DDKGPIOClose(DDKGPIOType DDK);
    ADDAPI DDK_STATUS ADDCALL DDKGPIOWrite(DDKGPIOType DDK, GPIO_PIN pin, bool State);

    /*******************/
    /*** CAN      *****/
    /*******************/
    typedef enum
    {
        ERROR_ACTIVE = 0,
        ERROR_PASSIVE = 1,
        ERROR_BUSOFF = 2,
        ERROR_UNKOWN = 255

    } CANBUSSTATE;

    typedef enum
    {
        CAN_BAUD_1000K,
        CAN_BAUD_500K,
        CAN_BAUD_400K,
        CAN_BAUD_250K,
        CAN_BAUD_125K,
        CAN_BAUD_100K,
        CAN_NUM_BAUDS
    } DDK_CAN_BAUD;

    ADDAPI DDKCANType ADDCALL DDKCANOpen(DDK_CAN_BAUD Baud);
    ADDAPI DDK_STATUS ADDCALL DDKCANWrite(DDKCANType DDK, uint32_t CANId, uint8_t registerAddress, const unsigned char *data, unsigned int numBytes);
    ADDAPI DDK_STATUS ADDCALL DDKCANRequestRead(DDKCANType DDK, uint32_t CANId, uint8_t registerAddress);
    ADDAPI DDK_STATUS ADDCALL DDKCANReadMsg(DDKCANType DDK, uint32_t *CANId, uint8_t *data, uint32_t *numBytes);
    ADDAPI DDK_STATUS ADDCALL DDKCANBlockingRead(DDKCANType DDK, uint32_t CANId, uint8_t registerAddress, uint8_t *data, uint32_t *numBytes);
    ADDAPI DDK_STATUS ADDCALL DDKCANClose(DDKCANType DDK);
    ADDAPI DDK_STATUS ADDCALL DDKCANSetBaud(DDKCANType DDK, DDK_CAN_BAUD Baud);
    ADDAPI CANBUSSTATE ADDCALL DDKCANErrorMode(DDKCANType DDK);
    ADDAPI void ADDCALL DDKCANReset(DDKCANType DDK);
    ADDAPI DDK_STATUS ADDCALL DDKCANRxMsgPresent(DDKCANType DDK);

    /*******************/
    /*** logger    *****/
    /*******************/
    // Function to convert DDK status  to string
    char *DDK_STATUS_to_string(int level);

    typedef enum
    {
        LOG_NOTSET = 0x01,
        LOG_DEBUG = 0x01,
        LOG_INFO = 0x02,
        LOG_WARNING = 0x03,
        LOG_ERROR = 0x04,
        LOG_DISABLED = 0x05
    } LOG_LEVEL_TYPE;

#define LOG_LEVEL LOG_WARNING
#define MODULE_NAME "UNKNOWN"

    ADDAPI void ADDCALL DDKSetLevelLOG(unsigned char level);
    void log_msg_status_string(LOG_LEVEL_TYPE level, char *module_name, char *message, char *status);
    void log_msg_status_int(LOG_LEVEL_TYPE level, char *module_name, char *message, unsigned int status);
    void log_msg_status_hex(LOG_LEVEL_TYPE level, char *module_name, char *message, unsigned int status);
#ifdef __cplusplus
}
#endif

#endif /* DDK_H */
