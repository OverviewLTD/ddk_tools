import ctypes
import os
import time
import pathlib
from enum import IntEnum
import logging


# Define the global logger at the module level
logger = logging.getLogger(__name__)

# Prevent the logger from inheriting handlers
logger.propagate = False

# Check if the logger already has handlers to avoid adding multiple handlers
if not logger.handlers:
    # Define the logging format
    FORMAT = "[%(levelname)s] [%(filename)s] %(message)s"
    
    # Create a console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # Create a formatter and set it for the console handler
    formatter = logging.Formatter(FORMAT)
    console_handler.setFormatter(formatter)
    
    # Add the handler to the logger
    logger.addHandler(console_handler)

# Set the logger level
logger.setLevel(logging.ERROR)






# Define the types we need.
class CtypesEnum(IntEnum):
    """A ctypes-compatible IntEnum superclass."""
    @classmethod
    def from_param(cls, obj):
        return int(obj)


class DDKLOGGER_LEVEL(CtypesEnum):
    LOG_NOTSET = 0x00
    LOG_DEBUG = 0x01
    LOG_INFO = 0x02
    LOG_WARNING = 0x03
    LOG_ERROR = 0x04
    LOG_DISABLED = 0x05

class DDKSTATUS(CtypesEnum):
    DDK_OK = 0x00
    DDK_NOT_FOUND = 0x01
    DDK_NACK= 0x02
    DDK_INVALID_PARAMETER = 0x03
    DDK_BUS_ERROR= 0x04

class DDK_NOT_FOUND_EXCEPTION(Exception):
    pass

class DDK_NOT_INITIALISED_EXCEPTION(Exception):
    pass

class DDK_NACK_EXCEPTION(Exception):
    pass

class DDK_INVALID_PARAMETER_EXCEPTION(Exception):
    pass

class DDK_BUS_ERROR_EXCEPTION(Exception):
    pass

###  DDK Version ###
__DDK_version__ = "0.0.1"


path = pathlib.Path(__file__).parent.resolve()


dll_path = os.path.join(path, 'DDK.dll')
    # Load the DLL

DDKDll = ctypes.cdll.LoadLibrary(dll_path)
I2C_Max_Len = 8
CAN_Max_Len = 8
c_ubyte_p = ctypes.POINTER(ctypes.c_ubyte)


def DDKversion():
    """
    Returns the version of DDK.
    """
    return __DDK_version__
  
def DDKSetLevelLOG( loglevel):
    DDKDll.DDKSetLevelLOG(loglevel)
    return DDKSTATUS.DDK_OK

class DDKI2C:
    def __init__(self, ExceptionHandling=True):
        self.DDKI2C = None
        self.Initialised = False
        self.ExceptionHandling = ExceptionHandling
        print("I2C Init")
    
    def Open(self):
        if(self.Initialised):
            self.Close()
        
        DDKI2COpen = DDKDll.DDKI2COpen
        DDKI2COpen.restype = ctypes.c_void_p
        self.DDKI2C = DDKI2COpen()
        
        if(self.DDKI2C):            
            self.Initialised = True
            return DDKSTATUS.DDK_OK
        else:
            self.Initialised = False
            if(self.ExceptionHandling):
                raise DDK_NOT_FOUND_EXCEPTION("DDKI2C Open failed")
            return DDKSTATUS.DDK_NOT_FOUND
        
    def OpenEx(self, LocationID):
        if(self.Initialised):
            self.DDKI2CClose()
        
        Loc = ctypes.c_uint(LocationID)

        DDKI2COpenEx = DDKDll.DDKI2COpenEx
        DDKI2COpenEx.restype = ctypes.c_void_p
        self.DDKI2C = DDKI2COpenEx(Loc)
        if(self.DDKI2C):
            self.Initialised = True
            return DDKSTATUS.DDK_OK
        else:
            self.Initialised = False
            if(self.ExceptionHandling):
                raise DDK_NOT_FOUND_EXCEPTION(f"DDKI2C OpenEx {LocationID} failed")
            return DDKSTATUS.DDK_NOT_FOUND
      

    def Close(self):
        if(self.Initialised):
            DDKI2C = ctypes.c_void_p(self.DDKI2C)
            DDKDll.DDKI2CClose(DDKI2C)
        self.Initialised = False

    def RaiseException(self, Code, Str):
        if(self.ExceptionHandling):
            if(DDKSTATUS.DDK_NOT_FOUND  == Code):
                raise DDK_NOT_FOUND_EXCEPTION(Str)
            elif(DDKSTATUS.DDK_NACK  == Code):
                raise DDK_NACK_EXCEPTION(Str)
            elif(DDKSTATUS.DDK_INVALID_PARAMETER  == Code):
                raise DDK_INVALID_PARAMETER_EXCEPTION(Str)
            elif(DDKSTATUS.DDK_BUS_ERROR  == Code):
                raise DDK_BUS_ERROR_EXCEPTION(Str)
            else:
                print("DDK I2C RaiseException Unknown return code " + str(Code))
                raise NotImplementedError("DDK I2C RaiseException Unknown return code " + str(Code))
    
    def Read(self, slaveAddress, registerAddress, numBytes):
        # DDKRead(unsigned char slaveAddress, unsigned char registerAddress, unsigned char *data, unsigned int numBytes)

        if(not self.Initialised):
            if(self.ExceptionHandling):
                raise DDK_NOT_INITIALISED_EXCEPTION(f"DDKI2C Read not initialised")
            else:
                print("DDKI2CRead() I2C not initialised")
            return False
        ReadBuf = (ctypes.c_ubyte * numBytes)()
        sAddr = ctypes.c_ubyte(slaveAddress)
        reg = ctypes.c_ubyte(registerAddress)
        bytes = ctypes.c_uint(numBytes)
        DDKI2C = ctypes.c_void_p(self.DDKI2C)
        
        ret = DDKDll.DDKI2CRead(DDKI2C, sAddr, reg, ctypes.cast(ReadBuf, c_ubyte_p), bytes)
        if(ret == DDKSTATUS.DDK_OK):
            Ret = ReadBuf[:]
            return Ret
        else:
            self.RaiseException(ret, "DDKI2C Read() failed")
            return []
        
    def ReadSlow(self, slaveAddress, registerAddress, numBytes):
        # DDKRead(unsigned char slaveAddress, unsigned char registerAddress, unsigned char *data, unsigned int numBytes)
        if(not self.Initialised):
            if(self.ExceptionHandling):
                raise DDK_NOT_INITIALISED_EXCEPTION(f"DDKI2C ReadSlow not initialised")
            else:
                print("DDKI2CReadSlow() I2C not initialised")
            return False
        ReadBuf = (ctypes.c_ubyte * numBytes)()
        sAddr = ctypes.c_ubyte(slaveAddress)
        reg = ctypes.c_ubyte(registerAddress)
        bytes = ctypes.c_uint(numBytes)
        
        DDKI2C = ctypes.c_void_p(self.DDKI2C)
        
        ret = DDKDll.DDKI2CReadSlow(DDKI2C, sAddr, reg, ctypes.cast(ReadBuf, c_ubyte_p), bytes)
        if(ret == DDKSTATUS.DDK_OK):
            Ret = ReadBuf[:]
            return Ret
        else:
            print("I2C Exception: " + str(ret))
            self.RaiseException(ret, "DDKI2C ReadSlow() failed")
            return []

    def ReadStretch(self, slaveAddress, registerAddress, numBytes):
        # DDKRead(unsigned char slaveAddress, unsigned char registerAddress, unsigned char *data, unsigned int numBytes)
        if(not self.Initialised):
            if(self.ExceptionHandling):
                raise DDK_NOT_INITIALISED_EXCEPTION(f"DDKI2C ReadStretch not initialised")
            else:
                print("DDKI2CReadStretch() I2C not initialised")
            return False
        ReadBuf = (ctypes.c_ubyte * numBytes)()
        sAddr = ctypes.c_ubyte(slaveAddress)
        reg = ctypes.c_ubyte(registerAddress)
        bytes = ctypes.c_uint(numBytes)
        DDKI2C = ctypes.c_void_p(self.DDKI2C)
        
        ret = DDKDll.DDKI2CReadStretch(DDKI2C, sAddr, reg, ctypes.cast(ReadBuf, c_ubyte_p), bytes)
        if(ret == DDKSTATUS.DDK_OK):
            Ret = ReadBuf[:]
            return Ret
        else:
            self.RaiseException(ret, "DDKI2C ReadStretch() NACK")
            return []

    def Write(self, slaveAddress, registerAddress, Data, Fast=False):
        # DDKWrite(unsigned char slaveAddress, unsigned char registerAddress, const unsigned char *data, unsigned int numBytes)
        if(not self.Initialised):
            if(self.ExceptionHandling):
                raise DDK_NOT_INITIALISED_EXCEPTION(f"DDKI2C Write not initialised")
            else:
                print("DDKI2CWrite() I2C not initialised")
            return False
        numBytes = len(Data)
        WriteBuf = (ctypes.c_ubyte * I2C_Max_Len)(*Data)
        sAddr = ctypes.c_ubyte(slaveAddress)
        reg = ctypes.c_ubyte(registerAddress)
        bytes = ctypes.c_uint(numBytes)
        DDKI2C = ctypes.c_void_p(self.DDKI2C)
        if(False == Fast):
            ret = DDKDll.DDKI2CWrite(DDKI2C, sAddr, reg, ctypes.cast(WriteBuf, c_ubyte_p), bytes)
        else:
            ret = DDKDll.DDKI2CWriteFast(DDKI2C, sAddr, reg, ctypes.cast(WriteBuf, c_ubyte_p), bytes)
        if(ret == DDKSTATUS.DDK_OK):
            return True
        else:
            self.RaiseException(ret, "DDKI2C Write() failed ")
            logger.error('I2C write failed ')
            return False



    def SetLatency(self, Latency):
        if(not self.Initialised):
            if(self.ExceptionHandling):
                raise DDK_NOT_INITIALISED_EXCEPTION(f"DDKI2C SetLatency not initialised")
            else:
                print("DDKI2CSetLatency() I2C not initialised")
            return
        DDKI2C = ctypes.c_void_p(self.DDKI2C)
        DDKDll.DDKI2CSetLatency(DDKI2C, Latency)


    def ScanDeviceID(self, ID):
        if(not self.Initialised):
            if(self.ExceptionHandling):
                raise DDK_NOT_INITIALISED_EXCEPTION(f"DDKI2C ScanDeviceID not initialised")
            else:
                print("DDKI2CScanDeviceID() I2C not initialised")
            return False
        DDKI2C = ctypes.c_void_p(self.DDKI2C)
        Present = DDKDll.DDKI2CScanDeviceID(DDKI2C, ID)
        if(Present == DDKSTATUS.DDK_OK):
            return True
        else:
            return False
    

        
    def FindDrives(self, start=0x28, end=0x29):
        if(not self.Initialised):
            if(self.ExceptionHandling):
                raise DDK_NOT_INITIALISED_EXCEPTION(f"DDKI2C FindDrives not initialised")
            else:
                print("DDKI2CScanDeviceID() I2C not initialised")
            return False
        Drives = []
        for i in range(start, end + 1):
            if(self.ScanDeviceID(i)):
                #print("Found at " + hex(i))
                Drives.append(i)
        return Drives

class DDKGPIO:
    GPIO_POWER_ON = 0
    GPIO_UART_SELECT = 1
    GPIO_DRIVE_KILL = 2
    GPIO_PAN_TILT = 3
    GPIO_CAN_INT = 4

    def __init__(self, ExceptionHandling=True):
        self.DDKGPIO = None
        self.Initialised = False
        self.ExceptionHandling = ExceptionHandling

    def Open(self):
        # bool DDKGPIOOpen(void)
        if(self.Initialised):
            self.DDKGPIOClose()
        
        DDKGPIOOpen = DDKDll.DDKGPIOOpen
        DDKGPIOOpen.restype = ctypes.c_void_p
        self.DDKGPIO = DDKGPIOOpen()
        if(self.DDKGPIO):
            self.Initialised = True
            return DDKSTATUS.DDK_OK
        else:
            self.Initialised = False
            if(self.ExceptionHandling):
                raise DDK_NOT_FOUND_EXCEPTION("DDKI2C Open failed")
            return DDKSTATUS.DDK_NOT_FOUND
        
    def OpenEx(self, LocationID):
        # bool DDKGPIOOpenEx(uint32 LocationID)
        if(self.Initialised):
            self.DDKGPIOClose()
        Loc = ctypes.c_uint(LocationID)

        DDKGPIOOpenEx = DDKDll.DDKGPIOOpenEx
        DDKGPIOOpenEx.restype = ctypes.c_void_p

        self.DDKGPIO = DDKGPIOOpenEx(Loc)
        if(self.DDKGPIO):
            self.Initialised = True
            return DDKSTATUS.DDK_OK
        else:
            self.Initialised = False
            if(self.ExceptionHandling):
                raise DDK_NOT_FOUND_EXCEPTION("DDKI2C Open failed")
            return DDKSTATUS.DDK_NOT_FOUND

    def Close(self):
        # bool DDKGPIOClose(void)
        if(self.Initialised):
            DDKGPIO = ctypes.c_void_p(self.DDKGPIO)
            DDKDll.DDKGPIOClose(DDKGPIO)
        self.Initialised = False


    def Write(self, Pin, Value):
        # void DDKGPIOWrite(bool Value)
        if(not self.Initialised):
            if(self.ExceptionHandling):
                raise DDK_NOT_INITIALISED_EXCEPTION(f"DDKGPIO.Write() not initialised")
            else:
                print("DDKGPIO.Write() GPIO not initialised")
            return DDKSTATUS.DDK_NOT_FOUND
        DDKGPIOWrite = DDKDll.DDKGPIOWrite
        DDKGPIO = ctypes.c_void_p(self.DDKGPIO)
        DDKGPIOWrite.argtypes = [ctypes.c_void_p, DDKGPIO, ctypes.c_bool]
        
        DDKGPIOWrite.restype = ctypes.c_bool
        
        Val = ctypes.c_bool(Value)
        return DDKGPIOWrite(DDKGPIO, Pin, Val)
    
class DDKCAN:
    def __init__(self):
        self.DDKCAN = None
        self.Initialised = False

    def Open(self, baud):
        if(self.Initialised):
            self.DDKCANClose()
        
        DDKCANOpen = DDKDll.DDKCANOpen
        DDKCANOpen.restype = ctypes.c_void_p
        self.DDKCAN = DDKCANOpen(baud)
        if(self.DDKCAN):
            print("Opened CAN")
            self.Initialised = True
        else:
            print("Failed to open CAN")
            self.Initialised = False
        return self.DDKCAN

    def Close(self):
        if(self.Initialised):
            DDKCAN = ctypes.c_void_p(self.DDKCAN)
            DDKDll.DDKCANClose(DDKCAN)
            print("Closed CAN")
        else:
            print("CAN not initialised, cannot close")
        self.Initialised = False
    
    def Write(self, CANId, registerAddress, Data):
        numBytes = len(Data)
        WriteBuf = (ctypes.c_ubyte * CAN_Max_Len)(*Data)
        id = ctypes.c_ulong(CANId)
        reg = ctypes.c_ubyte(registerAddress)
        bytes = ctypes.c_uint(numBytes)

        DDKCAN = ctypes.c_void_p(self.DDKCAN)
        ret = DDKDll.DDKCANWrite(DDKCAN, id, reg, ctypes.cast(WriteBuf, c_ubyte_p), bytes)
        if(ret != DDKSTATUS.DDK_OK):
            logger.error('CAN msg write error')
        return ret

    def ReadMsg(self, CANId, data, numBytes):
        # ADDAPI bool ADDCALL DDKCANReadMsg(uint32_t *CANId, uint8_t *data, uint32_t *numBytes);
        ReadBuf = (ctypes.c_ubyte * numBytes)()
        Id = ctypes.c_ulong(CANId)
        bytes = ctypes.c_uint(numBytes)

        DDKCAN = ctypes.c_void_p(self.DDKCAN)
        ret = DDKDll.DDKCANReadMsg(DDKCAN, Id, ctypes.cast(ReadBuf, c_ubyte_p), bytes)
        if(ret == DDKSTATUS.DDK_OK):
            Ret = ReadBuf[:]
            return Ret
        else:
            return []


    # ADDAPI bool ADDCALL DDKRequestReadCAN(uint32_t CANId, uint8_t registerAddress);
    # ADDAPI bool ADDCALL DDKBlockingReadCAN(uint32_t CANId, uint8_t registerAddress, uint8_t *data, uint32_t *numBytes);
    # ADDAPI bool ADDCALL DDKCloseCAN(void);
    # ADDAPI bool ADDCALL DDKSetSpeedCAN(DDK_CAN_BAUD Speed);


def DDKScanDevices():
    # uint32_t DDKNumConnectedDDKs(void);
    # int32_t DDKScanDevices(uint32_t *DeviceIDs, uint32_t Len);
    DDKScanDevicesFunc = DDKDll.DDKScanDevices

    NumDevices = DDKDll.DDKNumConnectedDDKs()
    if(NumDevices == 0):
        return []

    DeviceListRaw = ctypes.c_uint32 * (NumDevices)

    DDKScanDevicesFunc.argtypes = [DeviceListRaw, ctypes.c_uint32]
    DDKScanDevicesFunc.restype = ctypes.c_int32

    DeviceListArr = DeviceListRaw()

    ret = DDKScanDevicesFunc(DeviceListArr, NumDevices)

    if(ret > 0):
        DeviceList = []
        for Dev in DeviceListArr:
            DeviceList.append(Dev)
        return DeviceList
    else:
        return []

